#!/bin/bash

for c in chr2 chr3 chr21; do
    echo $c
    mv ${c}/${c}.gtf ${c}/${c}_new.gtf
done
    
